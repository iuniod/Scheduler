/**
 * SO, 2019
 * Lab #8
 *
 * Task #3, lin
 *
 * Thread safety
 */

/* Mark the begging of a critical section */
void acquire_lock(void);

/* Mark the ending of a critical section */
void release_lock(void);

