/**
 * SO, 2017 - Lab #07, Profiling
 * Task #3, Linux
 *
 * busy wating
 */

#include <stdio.h>

int main(void)
{

	/* Linux can run infinite loops in 5 seconds :) */
	while (1)
		;

	return 0;
}
