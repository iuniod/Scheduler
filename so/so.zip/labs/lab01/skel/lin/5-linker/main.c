/**
 * SO, 2016
 * Lab #1, Introduction
 *
 * Task #3-karma, Linux
 *
 * Having fun with link-time & run-time
 */
int str(void);

int main(void)
{
	str();

	return 0;
}
