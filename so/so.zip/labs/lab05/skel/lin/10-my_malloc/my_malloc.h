/**
  * SO, 2016
  * Lab #5
  *
  * Task #10, lin
  *
  */
#ifndef MY_MALLOC__
#define MY_MALLOC__

#include <sys/types.h>

void *my_malloc(size_t size);

#endif
