#ifndef WIN_LAB03_COMMON_H_
#define WIN_LAB03_COMMON_H_	1

#define BUFSIZE 4096
#define PIPE_NAME	"\\\\.\\pipe\\mynamedpipe"


#endif
