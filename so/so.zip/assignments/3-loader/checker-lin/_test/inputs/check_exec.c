void exit(int);

void _start()
{
	exit(0);
}
