#define VAR 0
