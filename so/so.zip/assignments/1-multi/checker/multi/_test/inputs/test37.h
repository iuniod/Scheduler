#ifndef _TEST_33_H_
#define _TEST_33_H_

int var;

#endif /* TEST_33_H_ */
