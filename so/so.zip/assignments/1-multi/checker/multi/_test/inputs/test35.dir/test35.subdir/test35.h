#define VAR 2
