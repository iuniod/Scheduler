int var;
