#ifndef _TEST38_H_
#define _TEST38_H_

#ifdef CUSTOM_DBG
#define DEBUG_STR CUSTOM_DBG
#else
#define DEBUG_STR "my debugging"
#endif

#include "debug.h"

#endif /* _TEST38_H_ */
