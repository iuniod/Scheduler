#define VAR 1
